export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBP9UsbIqJIRxtcORJ6gVhcbvZ8dSh5vTQ",
    authDomain: "blowed-code.firebaseapp.com",
    databaseURL: "https://blowed-code-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "blowed-code",
    storageBucket: "blowed-code.appspot.com",
    messagingSenderId: "64716051291",
    appId: "1:64716051291:web:3e8e6cb12afddfe7a7407e"
  }
};