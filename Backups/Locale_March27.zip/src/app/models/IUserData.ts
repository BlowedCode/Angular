export interface IUserData {
    username: string;
    password: string;
    email: string;
    dtregister: Date;
    dtlastlogin: Date;
}